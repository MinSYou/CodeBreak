﻿using System;

class Program
{
    static void Main(string[] args)
    {
        const int computerguess = 4;
        const int userguesses = 12;
        int guessesLeft = userguesses;

        // prompt user for font color
        Console.WriteLine("Welcome to CodeBreaker!");
        Console.Write("Enter a color for the text: ");
        string color = Console.ReadLine();

        // set console font color
        ConsoleColor fontColor;
        if (Enum.TryParse<ConsoleColor>(color, true, out fontColor))
        {
            Console.ForegroundColor = fontColor;
        }
        else
        {
            Console.WriteLine("Invalid color specified. Using default color.");
        }

        // generate random 4 digit no. 
        Random random = new Random();
        int[] code = new int[computerguess];
        for (int i = 0; i < computerguess; i++)
        {
            code[i] = random.Next(0, 9);
        }
        Console.WriteLine("Guess the 4 digit code!");

        while (guessesLeft > 0)
        {
            // get userguess
            Console.Write("Guess ({0} guesses left): ", guessesLeft);
            string input = Console.ReadLine();

            // check if userguess is actually 4 digits
            try
            {
                int[] guess = new int[computerguess];
                if (input.Length != computerguess)
                {
                    throw new ArgumentException($"Invalid guess length: {input.Length}. Please enter a guess with {computerguess} digits.");
                }
                for (int i = 0; i < computerguess; i++)
                {
                    if (!int.TryParse(input[i].ToString(), out guess[i]) || guess[i] < 0 || guess[i] > 9)
                    {
                        throw new ArgumentException("You have entered an invalid guess. Try again using numbers 1-9.");
                    }
                }

                // check if user guess equals computer guess
                int computerdigits = 0;
                for (int i = 0; i < computerguess; i++)
                {
                    if (guess[i] == code[i])
                    {
                        computerdigits++;
                    }
                    else if (Array.IndexOf(code, guess[i]) >= 0)
                    {
                        computerdigits++;
                    }
                }

                // print result
                if (computerdigits == computerguess)
                {
                    Console.WriteLine("You have entered the code correctly.");
                    return;
                }
                else if (guessesLeft == 1)
                {
                    Console.WriteLine("You have run out of guesses. The code was: {0}. Goodbye!", string.Join("", code));
                    return;
                }
                else
                {
                    Console.WriteLine("Incorrect guess. {0} correct digits.", computerdigits);
                    guessesLeft--;
                }
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception)
            {
                Console.WriteLine("An error occurred. Please try again.");
            }
        }
    }
}
